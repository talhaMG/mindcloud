# CustomerPreferences

## Properties
Name | Getter | Setter | Type | Description | Notes
------------ | ------------- | ------------- | ------------- | ------------- | -------------
**email_unsubscribed** | getEmailUnsubscribed() | setEmailUnsubscribed($value) | **bool** | The customer has unsubscribed from receiving marketing campaign emails. | [optional] 

Note: All properties are protected and only accessed via getters and setters.

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

